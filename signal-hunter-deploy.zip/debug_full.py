#!/usr/bin/env python3
"""
Signal Hunter 终极调试脚本
捕获所有错误并输出详细堆栈
"""

import sys
import traceback
import os
import asyncio
from datetime import datetime

# 强制输出所有错误
try:
    # 设置环境变量
    os.environ['PYTHONPATH'] = '.'
    
    # 导入所有模块
    print("=== 环境检查 ===")
    import yaml
    print(f"✅ PyYAML: {yaml.__version__}")
    
    from src.core.config import config
    print(f"✅ Config loaded: {config.config_path}")
    
    from src.core.database import Database
    from src.models.schemas import Signal, SignalType
    print("✅ 所有模块导入成功")
    
    print("\n=== 数据库测试 ===")
    db = Database()
    print("✅ Database 实例创建成功")
    
    signals = db.get_recent_signals(24)
    print(f"✅ 获取信号成功: {len(signals)} 条")
    
    # 测试保存信号
    test_signal = Signal(
        ticker='DEBUG',
        signal_type=SignalType.NEUTRAL,
        source_name='DebugBot',
        raw_text='Debug test signal',
        url='https://debug.com',
        timestamp=datetime.now(),
        confidence=0.9
    )
    db.save_signal(test_signal)
    print("✅ 保存信号成功")
    
    db.close()
    print("✅ 数据库关闭成功")
    
    print("\n=== 完整系统测试 ===")
    from src.core.engine import Engine
    engine = Engine()
    print("✅ Engine 实例创建成功")
    
    # 测试完整扫描流程
    print("正在运行完整扫描...")
    import asyncio
    asyncio.run(engine.run_cycle())
    print("✅ 完整扫描成功")
    
    print("\n=== 系统完全正常！ ===")
    
except Exception as e:
    print(f"\n❌ 捕获到错误: {type(e).__name__}")
    print(f"错误信息: {str(e)}")
    print("\n完整堆栈:")
    traceback.print_exc()
    print(f"\nExit code: 1")
    sys.exit(1)
