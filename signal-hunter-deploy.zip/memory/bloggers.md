| Name | URL | Platform | Weight |
|---|---|---|---|
| Vista | https://x.com/vista8 | twitter | 1.0 |
| QingQ | https://x.com/QingQ77 | twitter | 1.0 |
| Orange | https://x.com/oran_ge | twitter | 1.0 |
| FuSheng | https://x.com/FuSheng_0306 | twitter | 1.0 |
| 政事堂 | https://weixin.sogou.com/weixin?type=1&query=政事堂2019 | wechat | 1.0 |
