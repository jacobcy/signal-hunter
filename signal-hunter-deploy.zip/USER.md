# USER.md - About Your Human

- **Name:** 老板
- **What to call them:** 老板
- **Timezone:** Asia/Shanghai
- **Notes:** 
  - 核心目标：开发脚本并盈利。
  - 技术栈：Python。
  - 工作流：Git 版本控制。
  - 偏好：直接、高效，关注代码质量和交付速度。
